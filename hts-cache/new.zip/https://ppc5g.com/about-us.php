<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | PPC 5G</title>
    <link rel="icon" type="image/x-icon" href="images/ppclogo.png">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/style.css" type="text/css"/>

<div class="progress-container">
        <div class="progress-bar" id="myBar"></div>
    </div>  
    <header class="lightbrowm">
        <div class="container">
            <div class="row">
                <div class="col-sm-2 logo">
                    <a href="index.php"><img src="images/ppclogo.png" /></a>
                </div>
                <div class="col-lg-6 col-md-9 col-sm-9">
                    <h1>Welcome to PPC5G.com</h1>
                    <p>Web5G Technology Pvt Ltd Redefines Success with Unmatched Google Ads & Advanced Tracking Mastery, with a strong presence in Delhi NCR.</p>
                </div>
                <div class="col-sm-12 col-lg-4 col-md-12">
                    <ul>
                        <li><a href="tel:9999123123"> <img alt="" src="images/phone.png" height="20px" width="20px"> 9999-123-123 (Info)</a></li>
                        <li><a href="tel:8588001122"><img alt="" src="images/phone.png" height="20px" width="20px"> 8588-001122 (PPC Support)</a></li>
                        <li><a href="tel:7777909090"><img alt="" src="images/phone.png" height="20px" width="20px"> 7777-909090 (Audit & Consultancy)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header> 
    <div class="menu">
    <div class="container">
        <ul class="menulist">
            <li><a href="javascript:void(0);" class="menuicon" id="menushow"><i class="fa fa-bars" aria-hidden="true"></i> Menu</a></li>
        </ul>
        <a class="homeicon" href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a>
        <div class="clearfix"></div>
    </div>
<div class="menu childmenu">
        <div class="container">
            <!--<ul class="firstmenu">-->
            <!--    <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal1">Why Us</a></li>-->
            <!--    <li><a href="#bookaduit" class="openModalBtn" data-modal-target="modal2">Book Aduit</a></li>-->
            <!--    <li><a href="javascript:void(0);" class="menudropdown">Checklist <i class="fa fa-angle-down" aria-hidden="true"></i></a> -->
            <!--        <ul class="submenu open1">-->
                        <!-- <div class="arrow-up"></div> -->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal3"><i class="fa fa-angle-right" aria-hidden="true"></i> Before Selecting PPC Company</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal4"><i class="fa fa-angle-right" aria-hidden="true"></i> Landing Page Mistakes</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal5"><i class="fa fa-angle-right" aria-hidden="true"></i> Discussion With PPC Experts</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal6"><i class="fa fa-angle-right" aria-hidden="true"></i> Personalized PPC Consultation</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal8"><i class="fa fa-angle-right" aria-hidden="true"></i> Reasons Why Clients Love Us?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal9"><i class="fa fa-angle-right" aria-hidden="true"></i> Exclusive PPC Additional Services?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal10"><i class="fa fa-angle-right" aria-hidden="true"></i> Types of ads we are expertise</a></li>-->
            <!--        </ul>-->
            <!--    </li>-->
            <!--</ul>-->
            <div class="clearfix"></div>
        </div>
    </div>    
</div>
</div>    <main>
        <section class="bgcontent">
            <div class="container">
                <h1>ABOUT US</h1>
            </div>
        </section>
        <section class="aboutus lightgrey pad20">
            <div class="container">
                <div class="box_inner">
                    <ul>
                        <li><h3>Company Overview:</h3><hr> Greetings and a warm virtual hug from all of us at PPC5G Technology Pvt Ltd! We're thrilled to have you here, exploring the wonderful world of website design services that we offer.</li>
                        <li><h3>Our Journey:</h3><hr> Our story began back in 2015, with a handful of passionate individuals who believed in the magic of the web. Over the years, our dedication and love for design have transformed PPC5G Technology Pvt Ltd from a small seedling into a blossoming tree in the vast digital landscape.</li>
                        <li><h3>Meet Our Creative Family:</h3><hr> Imagine a group of coffee-loving, pixel-perfect dreamers who believe in the art of turning your ideas into vibrant online realities. Yes, that's us! We're not just a team; we're a family of designers, developers, and dream-chasers who thrive on infusing personality and soul into every website we create.</li>
                        <li><h3>Your Unique Story:</h3><hr> No two stories are the same, and that applies to businesses too. We're all about custom solutions that sync with your vision. We don't do one-size-fits-all. Instead, we dive into your goals, allowing us to create a digital masterpiece that truly embodies you.</li>
                        <li><h3>Moments of Joy:</h3><hr> Seeing our clients' eyes light up when they see their website come to life is what makes our hearts dance. Those are the moments that fuel our passion and remind us why we do what we do.</li>
                        <li><h3>Guided by Heart:</h3><br> At PPC5G Technology Pvt Ltd, our compass is our heart. We pour our love and expertise into every design, ensuring that your website not only looks stunning but also feels like home to your visitors.</li>
                        <li><h3>A Promise We Hold Dear:</h3><hr> When you choose us, you're not just getting a design service; you're entering a partnership built on trust, creativity, and shared dreams. We promise to hold your hand through every step of the journey, making your experience as joyful and exciting as the final outcome.</li>
                        <li><h3>Let's Start Your Chapter:</h3><br> Picture us as the authors who help pen the beginning of your online story. Whether you're a small business owner or an individual with a unique vision, we're here, excited and ready to bring your aspirations to life. Connect with us at +91 9999-123-123 or info@website5g.com or fill out our friendly online form, and let's embark on this enchanting adventure together. With digital love and endless enthusiasm, The PPC5G Technology Pvt Ltd Team</li>
                    </ul>
                </div>
            </div>
        </section>
    </main> 
    <footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 footerfirst">
                <h3>Connect with Our Team</h3>
                <h5>General Inquiries</h5>
                <ul>
                    <li><a href="tel:9999123123"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 9999-123-123</a></li>
                    <li><a href="mailto:info@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: info@ppc5g.com</a></li>
                </ul>
                <h5>PPC Support Team</h5>
                <ul>
                    <li><a href="tel:8588001122"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 8588-001122</a></li>
                    <li><a href="mailto:support@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: support@ppc5g.com</a></li>
                </ul>
                <h5>PPC Audit & Consultancy</h5>
                <ul>
                    <li><a href="tel:7777909090"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 7777-909090</a></li>
                    <li><a href="mailto:audit@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: audit@ppc5g.com</a></li>
                </ul>
            </div>
            <div class="col-sm-4 footerfirst">
                <h3>Contact with Us</h3>
                <ul>
                <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 626, 6th Floor, Signature Global Mall,<br>Sector-3, Vaishali, Ghaziabad,<br> Uttar Pradesh-201010</a></li>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.4736342932583!2d77.3329667742235!3d28.645533783492468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x64662107506a59b3%3A0x1952eb50974829ec!2sWeb5G%20Technology%20Private%20Limited!5e0!3m2!1sen!2sin!4v1695913605459!5m2!1sen!2sin" width="100%" height="220" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p>© 2023 PPC5G Technology Pvt. Ltd. All Right Reserved.</p>
    </div>
</footer>     
<div class="aboutactive">
<div class="menu_overlay">
    <div id="menuopen" class="menuslide">
        <img src="images/ppclogo.png" alt="" />
        <span class="comtitle">Web5G Technology Pvt. Ltd</span>
        <button id="menuclose"><i class="fa fa-times" aria-hidden="true"></i>   </button>
        <div class="menu_body">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="ppc-services.php">PPC - Google Ads Services</a></li>
                <li><a href="landing-page.php">Landing Page Design Services</a></li>
                <li><a href="website-design.php">Website Design Services</a></li>
                <!--<li><a href="ppc-audit-services.php">PPC Audit Services</a></li>-->
                <li><a href="javascript:void(0);" class="slidedownmenu">About Us<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul class="slidemenu">
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="about-director.php">About Director</a></li>
                    </ul>
                </li>
                <li><a href="legal.php">Legal</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
</div></div>

   
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>   
<script src="js/commonjs.js"></script>      
</body>
</html>